#!/usr/bin/python
# -*- coding: utf-8 -*-
import ply.lex as lex

#ENTREGA 1 ANALIZADOR LEXICO
#JOHN FREDDY SALAMANCA 1088317765
#CHRISTIAN HERRERA     9860957

#1. Diccionario de palabras reservadas
                     #  keys       values
palabrasReservadas  = {'class'   :'CLASS',
    	     	       'return'  :'RETURN',
    	               'this'    :'THIS',
		       'extends' :'EXTENDS',
	    	       'if'      :'IF',
		       'new'     :'NEW',
		       'void'    :'VOID',
		       'else'    :'ELSE',
		       'length'  :'LENGTH',
		       'int'     :'INT',
		       'while'   :'WHILE',
		       'true'    :'TRUE',
		       'boolean' :'BOOLEAN',
		       'break'   :'BREAK',
		       'false'   :'FALSE',
		       'string'  :'STRING',
		       'continue':'CONTINUE',
		       'null'    :'NULL',
	             }

#2. Lista de caracteres a reemplazar por "_"
listaCaracteresEspeciales = ['á','é','í','ó','ú','ñ','Á','É','Í','Ó','Ú','Ñ']

#3. Definicion de tokens
tokens = ['COMA',
	  'CORCHETEDER',
	  'CORCHETEIZQ',
	  'MAS',
	  'MENOS',
	  'MULT',
          'DIVISION',
	  'IGUAL',
	  'NOIGUAL',
	  'COMPARADOR',
          'NO',
          'LLAVEDER',
          'LLAVEIZQ',
          'MAYOR',
          'MAYORIGUAL',
          'MENOR',
          'MENORIGUAL',
          'O',
          'Y',
          'PARENIZQ',
          'PARENDER',
          'IDENTIFICADOR',
	  'HEXA',
	  'NUMERO',
	  'CADENA_CARACTERES',
	  'ERROR_CADENA_CARACTERES',
	  'PUNTOCOMA',
          'PUNTO',	
	  'MODULO',
          'COMENTARIO_UNILINEA',
	  'COMENTARIO_MULTILINEA',
	  'ERROR_COMENTARIO_MULTILINEA',
	  'BINARIO',
	  'CIENTIFICO'
         ]+ list(palabrasReservadas.values()) #Anexo a la lista de tokens inicial los valores del diccionario de palabras reservadas

#4. Tokens como variables o expresiones regulares
t_COMA 		= r','
t_CORCHETEDER   = r'\['
t_CORCHETEIZQ 	= r'\]'
t_MAS    	= r'\+'
t_MENOS   	= r'\-'
t_MULT   	= r'\*'
t_DIVISION  	= r'\/'
t_IGUAL  	= r'='
t_NOIGUAL 	= r'!='
t_COMPARADOR	= r'=='
t_NO		= r'!'
t_LLAVEDER	= r'{'
t_LLAVEIZQ	= r'}'
t_MAYOR		= r'>'
t_MAYORIGUAL	= r'>='
t_MENOR		= r'<'
t_MENORIGUAL	= r'=<'
t_O 		= r'(\|\|)|OR'
t_Y 		= r'AND|&&'
t_PARENIZQ  	= r'\('
t_PARENDER  	= r'\)'
t_PUNTOCOMA 	= r';'
t_PUNTO 	= r'\.'
t_MODULO 	= r'%'

#5. Tokens como funciones 
t_ignore = " \t"

def t_newline(t):
	r'\n+'
    	t.lexer.lineno += t.value.count("\n")

def t_CADENA_CARACTERES(t):
	r'".*"'
    	return t
   
def t_ERROR_CADENA_CARACTERES(t):
	#Las comillas sin cerrar se evaluan hasta el fin de una linea (salto de linea)
	#o cuando el error se encuentra en la ultima linea, se usa el caracter $ que representa End Of File	
	r'".+(\n|$)'
	print("\n*************************ERROR!!!!!***************************")	
	print("Comillas sin cerrar en la linea %d" %t.lineno)
	print("**************************************************************\n")
	#toca sumarle 1 al contador de lineas del lexer porque si \n esta
	#dentro de un token, no lo detecta en la funcion t_newline()	
	t.lexer.lineno += 1
	
def t_error(t):
	print("\n*************************ERROR!!!!!***************************")	
	print("No se reconoce el caracter '%s' de la linea %d" %(t.value[0],t.lineno))
	print("**************************************************************\n")
    	t.lexer.skip(1)

def t_COMENTARIO_UNILINEA(t):
	r'//.*\n'
	#toca sumarle 1 al contador de lineas del lexer porque si \n esta
	#dentro de un token, no lo detecta en la funcion t_newline()	
	t.lexer.lineno += 1
	return t

def t_COMENTARIO_MULTILINEA(t):
        #El ? que aparece en la expresion sirve para usar la expresion en modo lazy y no en greedy
	#En modo greedy tendria un problema si hay dos comentarios multilinea dentro del codigo
	#Buscar en google "ejemplos regex modo greedy" para mayor informacion
	r'/\*(.|\n)*?\*/'
	#toca sumar el numero de lineas al contador de lineas del lexer 
        #porque si \n esta dentro de un token, no lo detecta en la funcion t_newline()
	t.lexer.lineno += t.value.count("\n")
	return t

def t_ERROR_COMENTARIO_MULTILINEA(t):
	r'/\*(.|\n)+$'
	print("\n*************************ERROR!!!!!***************************")	
	print("Comentario multilinea sin cerrar en la linea %d" %t.lineno)
	print("**************************************************************\n")

def t_BINARIO(t):
	r'b’[01]+’'
	#aplico manipulacion de cadenas para extraer la parte de 0s y 1s que es la que me interesa convertir a formato decimal
	primeraComilla = t.value.find("’")
	ultimaComilla  = t.value.find("’",primeraComilla + 3) #por alguna extraña razon el simbolo ’ ocupa 3 caracteres y no uno 
        numeroBinario  = t.value[primeraComilla + 3:ultimaComilla]	
	print("el numero binario %s es %d en decimal " %(numeroBinario,int(numeroBinario,2)))        	
	t.value = int(numeroBinario,2)
    	return t

def t_IDENTIFICADOR(t):
	r'([a-zA-Z_]+[a-zA-ZáéíóúñÁÉÍÓÚÑ0-9_]*[a-zA-ZáéíóúñÁÉÍÓÚÑ_]+)|[a-zA-Z]'
    	#primero busco si la cadena es reservada para cambiarle el tipo de TOKEN
        #si la palabra no es reservada t.type continua siendo 'IDENTIFICADOR'
    	t.type = palabrasReservadas.get(t.value,'IDENTIFICADOR')
    	#si la palabra es un identificador, procedo a buscar si tiene caracteres especiales que se deban reemplazar
    	if t.type == "IDENTIFICADOR":
		for caracterEspecial in listaCaracteresEspeciales:
			t.value = t.value.replace(caracterEspecial,'_')
    	return t

def t_HEXA (t):
    	r'0[xX][0-9a-fA-F]+'
	print("el numero hexadecimal %s es %d en el sistema decimal" %(t.value,int(t.value,16)))        	
	t.value = int(t.value,16)
    	return t

def t_CIENTIFICO(t):
  	r'-?[0-9](\.\d+)?[eE]-?\d+'
	t.value=float(t.value)
	return t
		
def t_NUMERO(t):
    	r'(-)?(\d+)' 
   	t.value = int(t.value)
        if t.value < -2147483648 or t.value > 2147483647:
		print("\n*************************ERROR!!!!!***************************")
		print("el numero %d que aparece en la linea %d no esta permitido" %(t.value,t.lineno))
		print("**************************************************************\n")
	else: return t

#6. Creacion del analizador
analizador = lex.lex()

#7. Casos de prueba
#abrimos el archivo deseado y ponemos su contenido en la variable codigoFuente
codigoFuente = open('../test/codigoJavaBien.txt', 'r').read()
analizador.input(codigoFuente)

#8. Impresion por pantalla de tokens
while True:
	tok = analizador.token()
    	if not tok: break      #fin de la lista
    	print(tok)
